export const DEFAULT_STATE={
version:1,
theme:"light",
player:{level:4,pb:2},
blinkDog:{
abilities:{str:12,dex:16,con:12,int:8,wis:14,cha:11},
saves:{proficient:["dex","wis"]},
skills:{
perception:{proficient:true,expertise:false},
stealth:{proficient:true,expertise:false}
},
feats:[],
attacks:["bite"],
specialSkills:[],
advancementHistory:{}
}};