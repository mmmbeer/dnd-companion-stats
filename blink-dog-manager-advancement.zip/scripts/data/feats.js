export const FEATS=[
"Phase Skirmisher","Pack Harrier","Fey Phase Guard","Planar Tracker",
"Interplanar Tracker","Blink Grip","Fey Resilience","Echo Blink"
];