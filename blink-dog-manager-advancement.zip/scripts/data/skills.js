export const SPECIAL_SKILLS=[
"Flickering Hover","Fey Distraction","Phase Sense","Blink Anchor","Blinkcasting"
];