export const ATTACKS=[
"Phase Pounce","Flurry of Claws","Blink Ram","Displacement Rake"
];